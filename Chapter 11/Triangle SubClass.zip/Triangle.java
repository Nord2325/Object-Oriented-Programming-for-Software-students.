package Chapter11;

public class Triangle {

}
