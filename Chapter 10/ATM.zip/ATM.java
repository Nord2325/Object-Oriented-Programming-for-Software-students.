/* Shaun Nord
 * 08/30/2021
 */
package Chapter_9;

import java.util.Scanner;

public class ATM {

	public static void main(String[] args) {
	
			
		
		
			Scanner input = new Scanner(System.in);

			// Create array
			Account[] accounts = new Account[10];

			// Initialize accounts with balance of 100
			
			startingBalance(accounts);

			// Once the system starts, it will not stop
			do {
				// Prompt user to enter an id
				System.out.print("Enter an Account id (0-9): ");
				int id = input.nextInt();

				if (isValidID(id, accounts)) {
					int pick;
					do {	
						// Get user choice
						pick = mainMenu(input);
						if (transaction(pick)) {
								executeTransaction(pick, accounts, id, input);
						}
					} while (pick != 4); // If 4 exit main menu
				}
				// Once you exit, the system will prompt for an id again
			} while (true); 
		}

		/** Initialize accounts with balance of 100 */
		public static void startingBalance(Account[] a) {
			for (int i = 0; i < a.length; i++) {
				double startingBalance = 100;
				a[i] = new Account(i, startingBalance);
			}
		}

		/** Return true if choice is a transaction */
		public static boolean transaction(int pick) {
			return pick > 0 && pick < 4;
		}

		/** Return true if ID is valid */
		public static boolean isValidID(int id, Account[] a) {
			for (int i = 0; i < a.length; i++) {
				if (id == a[i].getId())
					return true;
			}
			return false;
		}

		/** Display main menu */
		public static int mainMenu(Scanner input) {
			System.out.print(
				"\nMain menu\n1: Check Balance\n2: Make A Withdraw" +
				"\n3: Submit A Deposit\n4: Exit\nEnter a Transaction Number: ");
			return input.nextInt();
		}

		/** Execute a Transaction */
		public static void executeTransaction(
			int p, Account[] a, int id, Scanner input) {
			switch (p) {
				case 1: // Viewing the current balance
						  System.out.println("The balance is " + a[id].getBalance());
						  break;
				case 2: // Withdraw money
						  System.out.print("Enter an amount to withdraw: "); 
						  a[id].withdraw(input.nextDouble());
						  break;
				case 3: // Deposit money
						  System.out.print("Enter an amount to deposit: "); 
						  a[id].deposit(input.nextDouble());
			}
		}
	} 
