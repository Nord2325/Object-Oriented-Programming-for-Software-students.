/* Shaun Nord
 * 08/19/2021
 */
package Chapter_6;

import java.util.Scanner;

public class Triangle_Method_6_19 {

	public static void main(String[] args) {
		
	Scanner input = new Scanner (System.in);
	
System.out.println ("Enter the length of the 3 sides of the triangle: ");
	double side1 = input.nextDouble();
	double side2 = input.nextDouble();
	double side3 = input.nextDouble();
	
	if (isValid(side1, side2, side3)) {
	 System.out.println ("Side 1: " + side1);
		System.out.println ("Side 2: " + side2);
			System.out.println ("Side 3: " + side3);
			area( side1, side2, side3);
	}
	else
		System.out.println("This is not a valid triangle");
	}

	
	
	/** Return true if the sum of every two sides is greater than the third side.*/
	public static boolean isValid(double side1, double side2, double side3) {
		
		boolean result;
		if (side1 + side2 > side3 && side1 + side3 > side2 && side2 + side3 > side1) {
			
						result = true;
		}
		else {
			
				result = false;
		}
		
							return result;
		  	  
		  
	}

	

	/** Return the area of the triangle. */
	public static double area(double side1, double side2, double side3) {
		
		double s = (side1 + side2 + side3) / 2;
			double area = Math.sqrt(s*(s-side1)*(s-side2)*(s-side3));
				System.out.printf ("Area: %1.1f", area);
			
				return area;
		
				
	}
	}
	
	
	

