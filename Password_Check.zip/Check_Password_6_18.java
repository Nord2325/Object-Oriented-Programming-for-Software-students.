/* Shaun Nord
 * 08-19-2021
 */
package Chapter_6;

import java.util.Scanner;

public class Check_Password_6_18 {

	public static void main(String[] args) {
Scanner input = new Scanner (System.in);

System.out.println ("Enter a password");
	String s = input.nextLine();


	System.out.println(
			(isValid(s) ? "Valid " : "Invalid ") + "Password");
	}

	public static boolean isValid(String s) {
	 int length = 8;	
	 int minimum = 2;	
		boolean valid = LValid(s, length) && lettersDigits(s) && digits(s, minimum);

		return valid;
	}

	public static boolean digits(String s, int n) {
		int digits = 0;
		for (int i = 0; i < s.length(); i++) {
			if (Character.isDigit(s.charAt(i))) {
				digits++;
			}
			if (digits >= n) {
				return true;
			}
		}
		return false;
	}

	public static boolean LValid(String s, int validLength) {
		return s.length() >= validLength;
	}

	public static boolean lettersDigits(String s) {
		for (int i = 0; i < s.length(); i++) {
			if (!Character.isLetterOrDigit(s.charAt(i))) {
				return false;
			}
		}
		return true;
	}

}