/* Shaun Nord
 * 08/17/2021
 */
package Chapter_6;

public class Conversions_Between_Feet_And_Meters_6_9 {

	public static void main(String[] args) {
		System.out.print("  Feet   Meters  ");
		System.out.println(" 	     Meters   Feet ");
		System.out.println ("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _");
		
		footToMeter(1);
		meterToFoot(20);
	
		
	

			

		for (double foot = 1.0, meter = 20.0; foot <= 10.0; foot++, meter += 5)
		 System.out.printf("%4.1f%10.3f%20.1f%10.3f\n", foot , footToMeter(foot), meter, meterToFoot(meter));
	}
		
	
		/** Convert from feet to meters */
		public static double footToMeter(double foot) {
					double meter = .305 * foot;
					
						
				
								return meter;
				
		}
		
		/** Convert from meters to feet */
		public static double meterToFoot(double meter) {
						double foot = 3.279 * meter;
						 
					
								return foot;
	}
}	

