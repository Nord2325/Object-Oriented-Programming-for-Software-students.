/*Shaun Nord
 * 08/23/2021
 */
package Chapter_9;

public class rectangleClass_9_1 {

	public static void main(String[] args) {
		
		rectangle rectangle1 = new rectangle (4,40);
		System.out.println ("Rectangle 1");
		System.out.println ("Width: " + rectangle1.width );
		System.out.println ("Height: " + rectangle1.height );
		System.out.println ("Area: " + rectangle1.getArea() );
		System.out.println ("Perimeter: " + rectangle1.getPerimeter() );
		
		rectangle rectangle2 = new rectangle (3.5, 35.9);
		System.out.println ("Rectangle 2");
		System.out.println ("Width: " + rectangle2.width );
		System.out.println ("Height: " + rectangle2.height );
		System.out.println ("Area: " + rectangle2.getArea() );
		System.out.println ("Perimeter: " + rectangle2.getPerimeter() );
		
		
		

		
		
	}

}
class rectangle {
	// height and width of the rectangle
	double height = 1;
	double width = 1;
	
	// rectangle object
	rectangle() {
	}
	//rectangle object
	rectangle (double newWidth , double newHeight) {
		width = newWidth;
		height = newHeight;
	}
	
	double getArea () {
		return width * height;
	}
	double getPerimeter () {
		return width * (2) + height * (2);
	}
	void setWH (double newWidth, double newHeight) {
		width = newWidth;
		height = newHeight;
	}
}
