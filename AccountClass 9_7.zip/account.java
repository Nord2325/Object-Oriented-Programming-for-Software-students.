package Chapter_9;

public class account {


		private int id = 0;
		private double balance = 0;
		private double annualInterestRate = 0;
		private String dateCreated = "";
		private int accountNumber = 0;
		private double monthlyInterestRate = 0;
		private double withdraw = 0;
		private double deposit = 0;
		private double monthlyInterest=0;
		
		
		
		public double getMonthlyInterest(double monthlyInterest) {
			return monthlyInterest;
		}
		public void setMonthlyInterest(double monthlyInterestRate) {
			this.monthlyInterest = (monthlyInterestRate / 100) * balance;
		}
		public double getWithdraw(double withdraw) {
			System.out.println("Withdrawl: $" + withdraw);
			return withdraw;
		}
		public void setWithdraw(double withdraw) {
			this.balance = balance - withdraw;
		}
		public double getDeposit(double deposit) {
			System.out.println("Deposit: $" + deposit);
			return deposit;
		}
		public void setDeposit(double deposit) {
			this.balance = balance + deposit;
		}
		public int getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(int accountNumber) {
			this.accountNumber = accountNumber;
		}
		public double getMonthlyInterestRate(double monthlyInterestRate) {
			return monthlyInterestRate;
		}
		public void setMonthlyInterestRate(double annualInterestRate) {
			this.monthlyInterestRate = (annualInterestRate / 100) / (12) * (100);
			System.out.println ("Monthly interest rate %" + monthlyInterestRate);
		}
		public int getId(int id) {
			System.out.println("Account ID : "+id);
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public double getBalance(double balance) {
			System.out.println("Starting balance: $" + balance);
			return balance;
			
		}
		public void setBalance(double balance, double deposit, double withdrawl, double monthlyInterestRate) {
			double balance1 = (balance + deposit - withdrawl) * (monthlyInterestRate / 100); 
			this.balance = balance1 + (balance + deposit - withdrawl);
			System.out.println("Total balance: $" + this.balance);
		}
		public double getAnnualInterestRate(double annualInterestRate) {
			System.out.println("Annual Interest Rate: %" + annualInterestRate);
			return annualInterestRate;
		}
		public void setAnnualInterestRate(double annualInterestRate) {
			this.annualInterestRate = annualInterestRate;
		}
		public String getDateCreated(String dateCreated) {
			System.out.println ("Account created on: ");
			return dateCreated;
		}
		public void setDateCreated(String dateCreated) {
			this.dateCreated = dateCreated;
		}
		public int getNewAccount() {
			return accountNumber;
		}
		public void setNewAccount(account newAccount) {
		this.accountNumber = accountNumber;
		}


	

}
