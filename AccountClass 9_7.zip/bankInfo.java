package Chapter_9;

public class bankInfo {

	public static void main(String[] args) {
		account newAccount = new account ();
		System.out.println(newAccount.getDateCreated("Aug 24 2021"));
		newAccount.getBalance(20000);
		newAccount.getId(1122);
		newAccount.getAnnualInterestRate(4.5);
		newAccount.setMonthlyInterestRate(4.5);
		newAccount.getWithdraw(2500);
		newAccount.getDeposit(3000);
		newAccount.setBalance (20000, 3000, 2500, .375);
		

	}

}
