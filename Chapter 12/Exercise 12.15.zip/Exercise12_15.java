/* Shaun Nord
 * 
 */

package Chapter12;


import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Exercise12_15 {
	public static void main(String[] args) throws Exception {
		// Check if file exists
		File file = new File("Exercise12.15.txt");
		if (file.exists()) {
			System.out.println("File already exists");
			System.exit(0);
		}

		try (PrintWriter output = new PrintWriter(file);)
		{
			
			for (int i = 0; i < 100; i++) {
				output.print(((int)(Math.random() * 1000) + 1));
				output.print(" ");
			}
		}

		// Crate and ArrayList
		ArrayList<Integer> list = new ArrayList<>();

		try(Scanner input = new Scanner(file);)
		{
			// Read the data back from the file
			while (input.hasNext()) {
				list.add(input.nextInt());
			}
		}

	
		Collections.sort(list);

		// Display data in increasing order
		System.out.print(list.toString());
		System.out.println();
	}
}


